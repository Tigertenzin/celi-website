# DoodleBloom

*Draw every day. Watch it grow.*

DoodleBloom gives every day one page to draw on. A gentle reminder nudges you to draw something, with no streaks, no scores and nothing to fail at: just a growing collection of the days you drew.

## At a glance

- **Developer:** Thomas Tenzin
- **Platforms:** iPhone, iPad and iPhone Duo. Requires iOS 26.6 or later.
- **Price:** Free. DoodleBloom Premium, an optional subscription ($2.99 a month, with a one-week free trial), adds the Studio and time-lapse replays. There's also an optional tip jar.
- **Status:** In public beta on TestFlight: https://testflight.apple.com/join/HPCEeByd
- **Website:** https://celeryboi.com/projects/doodlebloom/
- **Privacy:** No accounts, no ads, no tracking, and no data collected. https://celeryboi.com/projects/doodlebloom/privacy/
- **Contact:** oaksParceliOS@gmail.com

## Features

- **One page, every day.** A fresh page each day, drawn with Apple Pencil or a finger, on blank, lined, grid or dot paper. Each day stays open until a few hours after midnight, then it's kept as it was.
- **A roomy canvas.** The page never runs out of edge.
- **Watch your drawings grow.** Browse the days as a grid, a list, or a page-turning sketchbook, and favourite the ones you love.
- **Year in Bloom.** Turn a month or a whole year into a calendar or collage poster, ready to share.
- **Widgets.** Today's page, and favourite past drawings, on the Home Screen.
- **Prompts and reminders.** Optional daily prompts when you're stuck, and reminders at the times you choose, skipped on days you've already drawn.
- **Share and export.** PNG, transparent PNG or JPEG, light or dark, with or without the page's lines.
- **On all your devices.** Drawings sync with iCloud, protected so a drawing is never lost to an out-of-date device, with nightly backups to iCloud Drive.
- **DoodleBloom Premium.** The Studio: copy any day's drawing and keep working on it. Time-lapse replays: watch a drawing redraw itself, stroke by stroke, and share it as a video.

## In this kit

- **App Icons:** every icon, 1024 × 1024, in light and dark.
- **Screenshots / Unframed:** as the app shows them, for iPhone, iPad and both iPhone Duo displays.
- **Screenshots / Framed:** the same, in their device frames, on a transparent background.
- **Screenshots / App Store:** the App Store product page screenshots, with captions.
- **Artwork:** the product page header.

Screenshots show real drawings made in DoodleBloom. Device frames are from Apple Frames by MacStories.
